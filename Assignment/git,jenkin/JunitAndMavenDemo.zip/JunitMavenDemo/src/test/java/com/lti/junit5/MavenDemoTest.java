package com.lti.junit5;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class MavenDemoTest {

	@Test
	public void test() {
		assertEquals(2, 1);
	}
}
