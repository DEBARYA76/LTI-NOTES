package com.lti.junit5;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.lti.bookstore.model.Book;
import com.lti.bookstore.service.BookService;


class FirstJUnit5Test {

	BookService bookService=new BookService();
	
	
	
	
	@Test    // mark the method as test method
	void test() {
		//System.out.println("Hello Test");
		//assertEquals(3, 2);
		
	}
	
	@Test
	void assertTrueFalseMethod() {
		Book javaBook=new Book("1", "Java", "Simant");
		//bookService.addBook(javaBook);
		
		List<Book> listOfBooks= bookService.books();
		
		//assertTrue(listOfBooks.isEmpty());
		//assertTrue(listOfBooks.isEmpty(), "List of book is not empty");
		//assertTrue(listOfBooks.isEmpty(), ()->"List of books is not empty");
		
		//assertTrue(()->listOfBooks.isEmpty());
		
		//assertTrue(()->listOfBooks.isEmpty(), "List of books is not empty");
		
		//assertTrue(()->listOfBooks.isEmpty(), ()->"List of books is not empty");
		
		//assertFalse(listOfBooks.isEmpty());
		
		//assertFalse(listOfBooks.isEmpty(), "List of book is empty");
		
		assertFalse(()->listOfBooks.isEmpty(), ()->"List of books is not empty");
		
	}

	@Test
	void assertNullMethod() {
		Book javaBook=new Book("1", "Java", "Simant");
		Book pythonBook=new Book("2", "Python", "Simant");
		Book rubyBook=new Book("3", "Ruby", "Simant");
		Book scalaBook=new Book("4", "Scala", "Simant");
		
		bookService.addBook(javaBook);
		bookService.addBook(pythonBook);
		bookService.addBook(rubyBook);
		bookService.addBook(scalaBook);
		
		Book book=bookService.getBookById("6");
		
		//assertNull(book);
		//assertNull(book, "Book found");
		
		//assertNull(book, ()->"Book is not null");
		
		assertNotNull(book, ()->"Book is null");
	}
	
	@Test
	void assertEqualsMethod() {
		Book javaBook=new Book("1", "Java", "Simant");
		Book pythonBook=new Book("2", "Python", "Simant");
		Book rubyBook=new Book("3", "Ruby", "Simant");
		Book scalaBook=new Book("4", "Scala", "Simant");
		
		bookService.addBook(javaBook);
		bookService.addBook(pythonBook);
		bookService.addBook(rubyBook);
		bookService.addBook(scalaBook);
		
		Book book=bookService.getBookById("1");
		
		//assertEquals("1",book.getBookId());
		//assertEquals("Java", book.getTitle());
		assertEquals("Java Book", book.getTitle());
		
		
	}
}



















