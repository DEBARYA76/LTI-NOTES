package com.lti.junit5;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.jupiter.params.provider.EnumSource.Mode;
import org.junit.jupiter.params.provider.MethodSource;

import com.lti.bookstore.model.Colors;
import com.lti.calc.Calculator;
import com.lti.calc.StringTest;

class ParameterizedTestDemo {

	//@Test
	@ParameterizedTest
	@ValueSource(ints = {2,4,6,7,8})
	void testEvenNumbers(int number) {
		Calculator calculator=new Calculator();
		assertTrue(calculator.isEvenNumber(number));
		
	}
	
	@ParameterizedTest
	@ValueSource(strings = {"John","Mike","Simant"})
	void testString(String name) {
		assertEquals("Simant", name);
	}
	
	@ParameterizedTest
	@NullSource
	void testNullSourceMethod(String str) {
		StringTest stringTest=new StringTest();
		assertEquals(null, stringTest.changeToUpperCase(str));
	
	}
	
	@ParameterizedTest
	@EmptySource
	void testEmptySourceMethod(String str) {
		StringTest stringTest=new StringTest();
		assertEquals("", stringTest.changeToUpperCase(str));
	}
	
	@ParameterizedTest
	@NullAndEmptySource
	void testNullAndEmptySourceMethod(String str) {
		StringTest stringTest=new StringTest();
		
		assertEquals(str, stringTest.changeToUpperCase(str));
	}
	
	@ParameterizedTest
	@NullSource
	@EmptySource
	void testNullAndEmptySourceMethod1(String str) {
		StringTest stringTest=new StringTest();
		
		assertEquals(str, stringTest.changeToUpperCase(str));
	}
	
	@ParameterizedTest
	//@CsvSource({"'a','A'"})
	//@CsvSource({"a,A"})
//	@CsvSource({
//		"'a','A'",
//		"'b','B'"
//		
//		})
	//@CsvSource("a,''")
	//@CsvSource("'',''")
	@CsvSource(",")
	void csvSourceMethod(String input,String expect) {
		StringTest stringTest=new StringTest();
		//assertEquals(expect, stringTest.changeToUpperCase(input));
		//assertEquals("", stringTest.changeToUpperCase(input));
		assertNull(expect, ()->stringTest.changeToUpperCase(input));
	}
	
	@ParameterizedTest
	@CsvFileSource(resources = "/test.csv",numLinesToSkip = 2)
	void csvFileSourceMethod(String input,String expect) {
		StringTest stringTest=new StringTest();
		
		assertEquals(expect,stringTest.changeToUpperCase(input));
	}
	
	
	@ParameterizedTest
	//@EnumSource(value = Colors.class)
	//@EnumSource(value = Colors.class,names = {"BLUE","YELLOW","BLACK"})
	//@EnumSource(value = Colors.class,mode = Mode.EXCLUDE,names = {"BLUE","YELLOW","BLACK"})
	@EnumSource(value = Colors.class,mode = Mode.MATCH_ALL,names = "^(B|W).*$")
	void enumSourceMethod(Colors colors) {
		assertNotNull(colors);
	}
	
	public static Stream<String> stringProvider(){
		return Stream.of("John","Mike","Roger","Kevin");
	}
	
	
	@ParameterizedTest
	@MethodSource("stringProvider")
	void methodSourceMethod(String names) {
		assertEquals("Roger", names);
	}
	
	
	public static Stream<Arguments> stringProviderAruguments(){
		return Stream.of(
					Arguments.arguments("a","A"),
					Arguments.arguments("b","b"),
					Arguments.arguments("c","C")
				);
	}
	
	@ParameterizedTest
	@MethodSource("stringProviderAruguments")
	void argumentMethod(String input,String expect) {
		StringTest stringTest=new StringTest();
		assertEquals(expect, stringTest.changeToUpperCase(input));
	}
	
	@RepeatedTest(5)
	void simpleRepeatedTest() {
		assertTrue(0<5);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
 