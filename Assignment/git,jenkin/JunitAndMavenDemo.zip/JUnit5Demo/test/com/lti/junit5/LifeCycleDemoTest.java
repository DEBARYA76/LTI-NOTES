package com.lti.junit5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.lti.bookstore.model.Book;

//@TestInstance(Lifecycle.PER_METHOD)  //default mode
@TestInstance(Lifecycle.PER_CLASS)
class LifeCycleDemoTest {

	Book book;
	
	public LifeCycleDemoTest() {
		System.out.println("Constructor");
	}
	
	@BeforeAll
	//static void beforeAllMethod() {
	void beforeAllMethod() {
		System.out.println("Before All");
	}
	
	@AfterAll
	//static void afterAllMethod() {
	void afterAllMethod() {
		System.out.println("After All");
	}

	@BeforeEach
	void beforeEachMethod() {
		System.out.println("Before Each");
	}
	
	@AfterEach
	void afterEachMethod() {
		System.out.println("After Each");
	}
	
	@Test
	void testMethod1() {
		System.out.println("Test Method1");
	}
	@Test
	void testMethod2() {
		System.out.println("Test Method2");
	}
}











