package com.lti.junit5;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

class RepeatedTestDemo {

	public RepeatedTestDemo() {
		System.out.println("Constructor");
	}
	
	@BeforeAll
	static void beforeAllMethod() {
		System.out.println("Before All");
	}
	@AfterAll
	static void afterAllMethod() {
		System.out.println("After All");
	}
	@BeforeEach
	void beforeEachMethod() {
		System.out.println("Before Each");
	}
	@AfterEach
	void afterEachMethod() {
		System.out.println("After Each");
	}
	
//	@RepeatedTest(5)
//	void simpleRepeatedTest() {
//		assertTrue(0<5);
//	}

	@RepeatedTest(value = 5, name = "{displayName}= {currentRepetition}/{totalRepetitions}")
	@DisplayName("Repetition Test No. ")
	void simpleRepeatedTest() {
		assertTrue(0<5);
	}
	
	@RepeatedTest(value = 5, name = RepeatedTest.LONG_DISPLAY_NAME)
	@DisplayName("Repetition Test")
	void simpleRepeatedTest1() {
		assertTrue(0<5);
	}
}

















