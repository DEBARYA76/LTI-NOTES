import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

//interface MyBooleanSupplier<Boolean>{
//	boolean getAsBoolean();
//}


public class FuntionalInterfaceDemo {

	public static void main(String[] args) {
//		MyBooleanSupplier booleanSupplier=()->false;
//		
//		System.out.println(booleanSupplier.getAsBoolean());
		
		BooleanSupplier booleanSupplier=()->true;
		
		booleanSupplier.getAsBoolean();
		
		Supplier<String> stringSupplier=()->"Simant Setu";
		
		System.out.println(stringSupplier.get());
		
		Consumer<Integer> consumer=(num)->System.out.println(num*num);
		
		consumer.accept(10);

	}

}
