package com.lti.bookstore.model;

public enum Colors {
	RED,
	GREEN,
	BLUE,
	YELLOW,
	ORANGE,
	WHITE,
	BLACK
}
