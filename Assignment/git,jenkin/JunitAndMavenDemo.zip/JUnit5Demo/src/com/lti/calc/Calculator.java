package com.lti.calc;

public class Calculator {
	
	public boolean isEvenNumber(int number) {
		return number%2==0;
	}
}
