package com.lti.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.lti.dao.AlbumSongDao;
import com.lti.dao.AlbumSongDaoImpl;
import com.lti.entity.Album;
import com.lti.entity.Song;

public class AlbumSongTest {

	AlbumSongDao dao=new AlbumSongDaoImpl();
	
	@Test
	public void addOrUpdateAnAlbumTest() {
		Album album=new Album();
		album.setAlbumName("50 shades of kishore kumar");
		album.setLabel("T-Series");
		album.setNoOfSongs(10);
		album.setReleaseDate(LocalDate.of(1967, 9, 15));
		
		Album SavedAlbum= dao.addOrUpdateAnAlbum(album);
		
		assertNotNull(SavedAlbum);
	}
	
	@Test
	public void searchAlbumByIdTest() {
		Album album= dao.searchAlbumById(111);
		
		assertNotNull(album);
	}

	@Test
	public void viewAllAlbumsTest() {
		List<Album> albums= dao.viewAllAlbums();
		
		assertNotEquals(0, albums.size());
	}
	
	@Test
	public void addOrUpdateASongTest() {
		Album album=dao.searchAlbumById(567);
		assertNotNull(album);
		
		Song song=new Song();
		song.setArtist("Akshay Kumar");
		song.setLength(30);
		song.setSongTitle("Tu cheez");
		song.setAlbum(album);
		
		Song savedSong= dao.addOrUpdateASong(song);
		
		assertNotNull(savedSong);
	}
	
	@Test
	public void searchSongById() {
		Song song=dao.searchSongById(567);
		assertNotNull(song);
	}
	
	@Test
	public void viewAllSongs() {
		List<Song> songs=
				dao.viewAllSongs();
		
		assertNotEquals(0, songs.size());
	}
	
	@Test
	public void addAnAlbumWithSongs() {
	Album album=new Album();
	album.setAlbumName("Bemisal");
	album.setLabel("Shemaroo");
	album.setNoOfSongs(4);
	album.setReleaseDate(LocalDate.of(1978, 6, 24));
	
	
	List<Song> songs=new ArrayList<Song>();
	
	Song song1=new Song();
	song1.setArtist("Amitabh");
	song1.setLength(5);
	song1.setSongTitle("Ae ri pawan"); 
	songs.add(song1);
	
	Song song2=new Song();
	song2.setArtist("Rakhi");
	song2.setLength(3);
	song2.setSongTitle("Kitni Khoobsoorat");
	songs.add(song2);
	
	Song song3=new Song();
	song3.setArtist("Amitabh");
	song3.setLength(4);
	song3.setSongTitle("Main Tera");
	songs.add(song3);
	
	song1.setAlbum(album);
	song2.setAlbum(album);
	song3.setAlbum(album);
	
	album.setSongs(songs);
	
	dao.addOrUpdateAnAlbum(album);
	
	}
	
	@Test
	public void findAlbumBySongId() {
		Song song=dao.searchSongById(445);
		Album album=song.getAlbum();
		System.out.println(album.getAlbumId()+" "+album.getAlbumName());
	}
	
	@Test
	public void removeASong() {
		dao.removeSongById(446);
	}
	
	@Test
	public void fetchAllSongsToWhichASongBelongs() {
		Song song=dao.searchSongById(447);
		
		Album album=song.getAlbum();
		
		List<Song> songs=album.getSongs();
		
		songs.stream()
			.forEach(s->{
				System.out.println(s.getSongTitle()+" "+s.getAlbum().getAlbumId());
				}
			);
	}
	
	@Test
	public void updateSongDuration() {
		/*
		int rec= dao.updateSongDuration(447,12);
		assertNotEquals(0, rec);
		*/
		
		//get persisted song
		Song song=dao.searchSongById(447);
		//modify any fiels
		song.setLength(5); 
		//merge it again
		dao.addOrUpdateASong(song);
		
	}
	
	@Test
	public void getAllSongsByArtistName() {
		List<Song> songs = dao.SongsByArtist("Amitabh");
        for(Song song:songs) {
        System.out.println(song.getSongTitle());
    }
	}
	
	@Test
	public void getAllSongsByAlbumId() {
		Album a=dao.searchAlbumById(113);
        List<Song> songs = a.getSongs();

        songs.stream()
        .forEach(s ->{
            System.out.println(s.getSongId()+" "+s.getSongTitle());
        });
	}
	@Test
	public void getTheLongestSong() {
		//Song song=dao.getTheLongestSong();
		
		System.out.println(dao.getTheLongestSong().getSongTitle());
		
	}
	
	@Test
	public void getAlbumWithHighestNumberOfSongs() {
		
	}
	
	
	
}
