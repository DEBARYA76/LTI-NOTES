package com.lti.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import java.util.List;

import org.junit.Test;

import com.lti.dao.PersonDao;
import com.lti.dao.PersonDaoImpl;
import com.lti.entity.Passport;
import com.lti.entity.Person;

public class DemoTest {

	PersonDao dao = new PersonDaoImpl();

	@Test
	public void testFindPersonById() {

		Person p = dao.findPersonById(42);

		assertNotNull(p);

		System.out.println(p.getPersonId() + " " + p.getPersonName() + " " + p.getPersonAge() + " " + p.getPhoneNo());
	}
	
	@Test
	public void findPersonByPhoneNo() {
		Person p= dao.findPersonByPhoneNo("7685758575");
		assertNotNull(p);
	}
	
	@Test
	public void viewAllPersons() {
		List<Person> persons=dao.viewAllPersons();
		
		assertFalse(persons.isEmpty());
		
		for(Person p:persons) {
			System.out.println(p.getPersonId()+" "+p.getPersonName());
		}
	}
	
	@Test
	public void addNewPassportForAPerson() {
		
		Person person= dao.findPersonById(42);
		if(person!=null) {
			if(dao.findPassportByPersonId(42)!=null) {
				System.out.println("This person already have a passport");
			}
			else {
			Passport passport=new Passport();
			passport.setValidFrom(LocalDate.of(2000, 10, 12));
			passport.setValidTo(LocalDate.of(2010, 10, 11));
			passport.setPlaceOfIssue("Pune");
			
			passport.setPerson(person);
			dao.addNewPassportForAPerson(passport);
			}
		}
		else {
			System.out.println("Person not found.");
		}
	}
	
	@Test
	public void addNewPersonWithAPassport() {
		Person person=new Person();
		person.setPersonAge(24);
		person.setPersonName("Ray");
		person.setPhoneNo("4956768741");
		
		Passport passport=new Passport();
		passport.setPlaceOfIssue("Pune");
		passport.setValidFrom(LocalDate.now());
		passport.setValidTo(LocalDate.now().plusYears(10));
		
		passport.setPerson(person);
		person.setPassport(passport);
		
		dao.addOrUpdateAPerson(person);
	
	}
	
}
