package com.lti.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.lti.dao.GeneralInsuranceDao;
import com.lti.dao.GeneralInsuranceDaoImpl;
import com.lti.entity.Insurance;
import com.lti.entity.Vehicle;

public class InsuranceTest {

	GeneralInsuranceDao dao=new GeneralInsuranceDaoImpl();
	
	
	@Test
	public void addOrUpdateVehicle() {
		Vehicle vehicle=new Vehicle();
		vehicle.setBrand("TVS");
		vehicle.setModelNo("Apache");
		vehicle.setRegistrationNo("MH05AP3438");
		vehicle.setVehicleType("2-wheeler");
		
		Vehicle vehicle2= dao.registerOrupdateVehicle(vehicle);
		
		assertNotNull(vehicle2);
	}
	
	@Test
	public void searchVehicleById() {
		Vehicle vehicle=dao.searchVehicleById(5001);
		assertNotNull(vehicle);
		//assertNull(vehicle);
	}
	@Test
	public void addOrUpdateInsurance(){
		
		Vehicle vehicle=dao.searchVehicleById(5001);
		
		Insurance insurance=new Insurance();  // from HTML page-->angular code-->angular service-->Java Controller
		                                      //-->Java Service-->Java DAO
		insurance.setCompanyName("Reliance");
		insurance.setNoOfYears(2);
		insurance.setPremiumAmount(5000);
		insurance.setVehicleType("2-wheeler");
		insurance.setVehicle(vehicle); // a foreign key column will be created in insurance table
		
		dao.addOrUpdateInsurance(insurance);
	}

	
}
