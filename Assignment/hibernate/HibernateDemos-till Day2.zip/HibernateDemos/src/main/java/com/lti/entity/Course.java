package com.lti.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

//@Entity
public class Course {

	@Id
	@SequenceGenerator(name = "course_seq", initialValue = 201, allocationSize = 1)
	@GeneratedValue(generator = "course_seq", strategy = GenerationType.SEQUENCE)
	int courseId;
	String courseName;
	int courseDuration;
	double courseFee;

	
	Student student;
	
}
