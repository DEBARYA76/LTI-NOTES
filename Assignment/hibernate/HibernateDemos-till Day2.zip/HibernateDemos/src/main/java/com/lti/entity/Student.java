package com.lti.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

//@Entity
public class Student {
	
	@Id
	@SequenceGenerator(name = "stud_seq", initialValue = 101, allocationSize = 1)
	@GeneratedValue(generator = "stud_seq", strategy = GenerationType.SEQUENCE)
	int rollNo;
	String name;
	LocalDate dateOfBirth;
	String email;
	String phoneNo;
	
	
	Course course;
}
