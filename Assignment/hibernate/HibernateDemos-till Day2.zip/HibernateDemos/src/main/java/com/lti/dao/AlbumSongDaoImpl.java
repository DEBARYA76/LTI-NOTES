package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.swing.tree.AbstractLayoutCache;

import com.lti.entity.Album;
import com.lti.entity.Song;

public class AlbumSongDaoImpl implements AlbumSongDao {

	EntityManagerFactory emf;
	EntityManager em;
	EntityTransaction tx;
	
	public AlbumSongDaoImpl() {
		emf=Persistence.createEntityManagerFactory("oracle-pu");
		em=emf.createEntityManager();
		tx=em.getTransaction();
	}
	
	//Tested
	public Album addOrUpdateAnAlbum(Album album) {
		tx.begin();
		Album albumPersisted=em.merge(album);
		tx.commit();
		return albumPersisted;
	}

	//Tested
	public Album searchAlbumById(int albumId) {
		
		return em.find(Album.class, albumId);
	}

	//Tested
	public List<Album> viewAllAlbums() {
//		String jpql="select alb from Album alb";
//		TypedQuery<Album> query=em.createQuery(jpql, Album.class);
//		List<Album> albums=query.getResultList();
//		return albums;
		
		return em.createQuery("select alb from Album alb", Album.class)
				 .getResultList();
	}
	//Tested
	public Song addOrUpdateASong(Song song) {
		tx.begin();
		Song songPersisted=em.merge(song);
		tx.commit();
		return songPersisted;
	}
	
	//Tested
	public Song searchSongById(int songId) {
		
		return em.find(Song.class, songId);
	}
	
	//Tested
	public List<Song> viewAllSongs() {
		
		return em.createQuery("select sng from Song sng", Song.class)
				.getResultList();
	}

	public void removeSongById(int songId) {
		Song song=searchSongById(songId);
		tx.begin();
		em.remove(song);
		tx.commit();
		System.out.println("Song removed.");
	}
	
	public int updateSongDuration(int songId,double length) {
		
		String jpql="update Song sng set sng.length=:len where "
				+ "sng.songId=:sid";
		tx.begin();
		Query query=em.createQuery(jpql);
		query.setParameter("len", length);
		query.setParameter("sid", songId);
		
		int rec=query.executeUpdate();
		tx.commit();
		return rec;
	}
	
	public Song getTheLongestSong() {

        return em.createQuery( "select sng from Song sng where sng.length = (select max(sng.length) from Song sng)",Song.class)
        		.getSingleResult();
    }
	
	public List<Song> SongsByArtist(String artist) {
        String jpql ="select sng from Song sng where sng.artist=:artistName";
        tx.begin();
        Query query = em.createQuery(jpql);
        query.setParameter("artistName",artist);
        List<Song> songs = query.getResultList();

        tx.commit();
        return songs;
    }
	public Album getAlbumWithHighestNumberOfSongs() {
		return null;
	}
}
