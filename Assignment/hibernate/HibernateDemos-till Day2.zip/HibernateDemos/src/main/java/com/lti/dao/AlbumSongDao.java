package com.lti.dao;

import java.util.List;

import com.lti.entity.Album;
import com.lti.entity.Song;

public interface AlbumSongDao {

	Album addOrUpdateAnAlbum(Album album);
	Album searchAlbumById(int albumId);
	List<Album> viewAllAlbums();
	
	Song addOrUpdateASong(Song song);
	Song searchSongById(int songId);
	List<Song> viewAllSongs();
	
	void removeSongById(int songId);
	
	public int updateSongDuration(int songId,double length);
	
	Song getTheLongestSong();
	List<Song> SongsByArtist(String artist);
	Album getAlbumWithHighestNumberOfSongs();
}
