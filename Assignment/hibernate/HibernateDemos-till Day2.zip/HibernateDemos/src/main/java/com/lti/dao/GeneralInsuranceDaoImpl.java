package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.lti.entity.Insurance;
import com.lti.entity.Vehicle;

public class GeneralInsuranceDaoImpl implements GeneralInsuranceDao {

	EntityManagerFactory emf;
	EntityManager em;
	EntityTransaction tx;
	
	public GeneralInsuranceDaoImpl() {
		emf=Persistence.createEntityManagerFactory("oracle-pu");
		em=emf.createEntityManager();
		tx=em.getTransaction();
	}
	
	//Tested
	public Insurance addOrUpdateInsurance(Insurance insurance) {
		
		tx.begin();
		Insurance insurancePersisted= em.merge(insurance);
		tx.commit();
		return insurancePersisted;
	}

	public List<Insurance> viewAllInsurances() {
		String jpql="select ins from Insurance ins";
		
		return em.createQuery(jpql).getResultList();
	}

	public Insurance searchInsuranceByNo(int insuranceNo) {
		
		return em.find(Insurance.class, insuranceNo);
	}

	public List<Insurance> viewAllInsurancesByType(String vehicleType) {
		String jpql="select ins from Insurance ins where ins.vehicleType=:vt";
		Query query=em.createQuery(jpql);
		query.setParameter("vt", vehicleType);
		
		return query.getResultList();
	}

	//Tested
	public Vehicle registerOrupdateVehicle(Vehicle vehicle) {
		tx.begin();
		Vehicle vehiclePersisted= em.merge(vehicle);
		tx.commit();
		return vehiclePersisted;
	}

	//Tested
	public Vehicle searchVehicleById(int vehicleId) {
		
		return em.find(Vehicle.class, vehicleId);
	}

	public Insurance getInsuranceDetailsByVehicleId(int vehicleId) {
		
		return searchVehicleById(vehicleId).getInsurance();
	}

	public Vehicle getVehicleDetailsByInsuranceNo(int insuranceNo) {
		
		return searchInsuranceByNo(insuranceNo).getVehicle();
	}

}
