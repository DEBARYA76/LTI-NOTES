package com.lti.entity;

public enum AccountType {
	Savings,Current
}
