package com.lti.entity;

public enum TransactionType {
	Credit,Debit
}
