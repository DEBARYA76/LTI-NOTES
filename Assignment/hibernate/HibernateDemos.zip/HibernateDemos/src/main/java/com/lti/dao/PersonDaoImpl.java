package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.lti.entity.Passport;
import com.lti.entity.Person;

public class PersonDaoImpl implements PersonDao {

	EntityManagerFactory emf;
	EntityManager em; // peristence context
	EntityTransaction tx;
	Query qry;

	public PersonDaoImpl() {
		emf = Persistence.createEntityManagerFactory("oracle-pu");
		em = emf.createEntityManager();
	}

//	public Person addNewPerson(Person person) {
//		tx=em.getTransaction();
//		
//		tx.begin();
//		em.persist(person);   //add a new record in the table
//		tx.commit();
//		
//		
//		return null;
//	}
//	public Person updateAPerson(Person person) {
//		tx=em.getTransaction();
//		
//		tx.begin();
//		Person persistedPerson=	em.merge(person);
//		tx.commit();
//		return persistedPerson;
//	}

	public Person addOrUpdateAPerson(Person person) {
		tx = em.getTransaction();

		tx.begin();
		Person persistedPerson = em.merge(person);
		tx.commit();
		return persistedPerson;
	}

	public Person findPersonById(int personId) {
		Person p = em.find(Person.class, personId); // only work for PK value
		return p;
	}

	public List<Person> viewAllPersons() {
		String jpql = "select p from Person p order by p.personId";
		qry = em.createQuery(jpql);
		List<Person> persons = qry.getResultList();
		return persons;
	}

	public Person findPersonByPhoneNo(String phoneNo) {
		// select * from tbl_person where person_phone=?
		String jpql = "select p from Person p where p.phoneNo=:phno";
		qry = em.createQuery(jpql);
		qry.setParameter("phno", phoneNo);
		Person p = (Person) qry.getSingleResult();
		return p;
	}

	public Passport addNewPassportForAPerson(Passport passport) {
		tx = em.getTransaction();

		tx.begin();
		Passport passport2 = em.merge(passport);
		tx.commit();

		return passport2;
	}

	public Passport findPassportByPersonId(int personId) {
		Passport passport = null;
		String jpql = "select ps from Passport ps where ps.person.personId=:pid";
		try {
			qry = em.createQuery(jpql);
			qry.setParameter("pid", personId);

			passport = (Passport) qry.getSingleResult();
		} catch (Exception e) {
			return passport;
		}

		return passport;
	}

}
