package com.lti.dao;

import java.util.List;

import com.lti.entity.Passport;
import com.lti.entity.Person;

public interface PersonDao {

	Person addOrUpdateAPerson(Person person);
	//Person updateAPerson(Person person);
	Person findPersonById(int personId);
	Person findPersonByPhoneNo(String phoneNo);
	List<Person> viewAllPersons();
	
	Passport addNewPassportForAPerson(Passport passport);
	Passport findPassportByPersonId(int personId);
}
