package com.lti.main;

import com.lti.dao.PersonDao;
import com.lti.dao.PersonDaoImpl;
import com.lti.entity.Person;

public class Main {

	public static void main(String[] args) {
		PersonDao dao=new PersonDaoImpl();
		
//		Person person=new Person();
//		person.setPersonName("John");
//		person.setPersonAge(20);
//		person.setPhoneNo("7685758575");
//		
//		dao.addNewPerson(person);
		
		Person person=new Person();
		person.setPersonId(100);
		person.setPersonName("Jane");
		person.setPersonAge(25);
		person.setPhoneNo("9797966885");
		
		Person p=dao.addOrUpdateAPerson(person);
		
		System.out.println(p.getPersonId());
		System.out.println(p.getPersonName());
		System.out.println(p.getPersonAge());
		System.out.println(p.getPhoneNo());
		
		
		

	}

}
