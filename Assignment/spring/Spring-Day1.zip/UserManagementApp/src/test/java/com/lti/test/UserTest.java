package com.lti.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.dao.UserDao;
import com.lti.dao.UserDaoImpl;
import com.lti.entity.User;

public class UserTest {

	UserDao dao;
	
	@Before
	public void initializeDao() {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring-config.xml");
		dao=context.getBean(UserDao.class);
	}
	
	@Test
	public void addOrUpdateUserTest() {
		User user=new User();
		user.setUserName("John");
		user.setEmail("john@lti.com");
		user.setPassword("John@123");
		user.setMobile("9876543645");
		
		User savedUser= dao.addOrUpdateUser(user);
		
		assertNotNull(savedUser);
	}

}
