package com.lti.entity;

public interface HardDisk {
	void hardDiskDetails();
}
