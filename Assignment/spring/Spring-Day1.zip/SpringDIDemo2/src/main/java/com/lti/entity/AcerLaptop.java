package com.lti.entity;

import org.springframework.stereotype.Component;

@Component
public class AcerLaptop implements Laptop {

	public void details() {
		System.out.println("This is Acer Laptop.");

	}

}
