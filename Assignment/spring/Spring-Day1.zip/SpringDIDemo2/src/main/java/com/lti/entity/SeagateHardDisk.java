package com.lti.entity;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Qualifier("sea")
public class SeagateHardDisk implements HardDisk {

	public void hardDiskDetails() {
		System.out.println("Seagate HDD inserted.");

	}

}
