package com.lti.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.entity.AcerLaptop;
import com.lti.entity.Bike;
import com.lti.entity.Car;
import com.lti.entity.HpLaptop;
import com.lti.entity.Laptop;
import com.lti.entity.Vehicle;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("spring-config.xml");
		
		
//		Vehicle vehicle=context.getBean(Bike.class);
//		vehicle.run();
		
		Laptop laptop=context.getBean(HpLaptop.class);
		laptop.details();
	}

}
