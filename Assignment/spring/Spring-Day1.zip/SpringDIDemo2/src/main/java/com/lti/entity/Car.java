package com.lti.entity;

import org.springframework.stereotype.Component;

@Component
public class Car implements Vehicle {

	public void run() {
		System.out.println("Car is running.");

	}

}
