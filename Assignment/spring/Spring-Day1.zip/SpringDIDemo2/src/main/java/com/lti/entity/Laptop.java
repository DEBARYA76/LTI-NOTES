package com.lti.entity;

public interface Laptop {
	void details();
}
