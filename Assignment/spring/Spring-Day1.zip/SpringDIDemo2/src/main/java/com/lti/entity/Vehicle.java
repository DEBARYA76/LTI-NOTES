package com.lti.entity;

public interface Vehicle {
	void run();
}
