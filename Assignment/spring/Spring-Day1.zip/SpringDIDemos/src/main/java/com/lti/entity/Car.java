package com.lti.entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Car {
	String model;
	String color;
	double price;
	String engineType;
	
	@Autowired      //Field Injection
	Tyre tyre;  //new Tyre();

	public Car() {
		
	}
	
	public String getEngineType() {
		return engineType;
	}


	public void setEngineType(String engineType) {
		this.engineType = engineType;
	}


	public Tyre getTyre() {
		return tyre;
	}


	public void setTyre(Tyre tyre) {
		this.tyre = tyre;
	}


	public Car(String model, String color, double price, String engineType, Tyre tyre) {
		this.model = model;
		this.color = color;
		this.price = price;
		this.engineType = engineType;
		this.tyre = tyre;
	}


	public Car(String model, String color, double price) {
		
		this.model = model;
		this.color = color;
		this.price = price;
	}

	
	public Car(String model, String color, double price, String engineType) {
		super();
		this.model = model;
		this.color = color;
		this.price = price;
		this.engineType = engineType;
	}


	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void start() {
		System.out.println("Car has started");
	}
	
	public void showCarDetails() {
		System.out.println("Model: "+model);
		System.out.println("Color: "+color);
		System.out.println("Price: "+price);
		System.out.println("Engine type: "+engineType);
		System.out.println(tyre.getMake()+" "+tyre.getSize()+" "+tyre.getType());
	}
}
