package com.lti.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.lti.entity.Car;
import com.lti.entity.Tyre;

@Configuration
@ComponentScan(basePackages = "com.lti")
public class Config {

	/*
	 * @Bean Tyre getTyre() { return new Tyre("MRF","Big","tubeless"); }
	 */
}
